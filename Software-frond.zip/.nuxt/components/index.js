export const AdminTemplate = () => import('../..\\components\\AdminTemplate.vue' /* webpackChunkName: "components/admin-template" */).then(c => wrapFunctional(c.default || c))
export const JcLoader = () => import('../..\\components\\JcLoader.vue' /* webpackChunkName: "components/jc-loader" */).then(c => wrapFunctional(c.default || c))
export const NuxtLogo = () => import('../..\\components\\NuxtLogo.vue' /* webpackChunkName: "components/nuxt-logo" */).then(c => wrapFunctional(c.default || c))
export const Tutorial = () => import('../..\\components\\Tutorial.vue' /* webpackChunkName: "components/tutorial" */).then(c => wrapFunctional(c.default || c))
export const CrudCreate = () => import('../..\\components\\crud\\Create.vue' /* webpackChunkName: "components/crud-create" */).then(c => wrapFunctional(c.default || c))
export const CrudUpdate = () => import('../..\\components\\crud\\Update.vue' /* webpackChunkName: "components/crud-update" */).then(c => wrapFunctional(c.default || c))
export const BaseAside = () => import('../..\\components\\base\\Aside.vue' /* webpackChunkName: "components/base-aside" */).then(c => wrapFunctional(c.default || c))
export const BaseFooter = () => import('../..\\components\\base\\Footer.vue' /* webpackChunkName: "components/base-footer" */).then(c => wrapFunctional(c.default || c))
export const BaseNav = () => import('../..\\components\\base\\Nav.vue' /* webpackChunkName: "components/base-nav" */).then(c => wrapFunctional(c.default || c))
export const PosArticulo = () => import('../..\\components\\pos\\Articulo.vue' /* webpackChunkName: "components/pos-articulo" */).then(c => wrapFunctional(c.default || c))
export const PosArticuloVenta = () => import('../..\\components\\pos\\ArticuloVenta.vue' /* webpackChunkName: "components/pos-articulo-venta" */).then(c => wrapFunctional(c.default || c))
export const PosArticuloVentaImage = () => import('../..\\components\\pos\\ArticuloVentaImage.vue' /* webpackChunkName: "components/pos-articulo-venta-image" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
