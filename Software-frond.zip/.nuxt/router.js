import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _f4c4ba32 = () => interopDefault(import('..\\pages\\cajas\\index.vue' /* webpackChunkName: "pages/cajas/index" */))
const _69968610 = () => interopDefault(import('..\\pages\\compras\\index.vue' /* webpackChunkName: "pages/compras/index" */))
const _bd248004 = () => interopDefault(import('..\\pages\\inventario\\index.vue' /* webpackChunkName: "pages/inventario/index" */))
const _27e9bad2 = () => interopDefault(import('..\\pages\\templateadmin.vue' /* webpackChunkName: "pages/templateadmin" */))
const _37d898e5 = () => interopDefault(import('..\\pages\\test.vue' /* webpackChunkName: "pages/test" */))
const _37f75088 = () => interopDefault(import('..\\pages\\ventas\\index.vue' /* webpackChunkName: "pages/ventas/index" */))
const _34f6803e = () => interopDefault(import('..\\pages\\auth\\login.vue' /* webpackChunkName: "pages/auth/login" */))
const _2907c678 = () => interopDefault(import('..\\pages\\cajas\\historial.vue' /* webpackChunkName: "pages/cajas/historial" */))
const _50d00041 = () => interopDefault(import('..\\pages\\compras\\lista.vue' /* webpackChunkName: "pages/compras/lista" */))
const _dd118784 = () => interopDefault(import('..\\pages\\configuracion\\articulos\\index.vue' /* webpackChunkName: "pages/configuracion/articulos/index" */))
const _67e37f7e = () => interopDefault(import('..\\pages\\configuracion\\categorias\\index.vue' /* webpackChunkName: "pages/configuracion/categorias/index" */))
const _7bd76507 = () => interopDefault(import('..\\pages\\configuracion\\marcas\\index.vue' /* webpackChunkName: "pages/configuracion/marcas/index" */))
const _089a713d = () => interopDefault(import('..\\pages\\configuracion\\medidas\\index.vue' /* webpackChunkName: "pages/configuracion/medidas/index" */))
const _59d3279e = () => interopDefault(import('..\\pages\\configuracion\\sucursal\\index.vue' /* webpackChunkName: "pages/configuracion/sucursal/index" */))
const _8237bf9e = () => interopDefault(import('..\\pages\\usuarios\\medidas\\index.vue' /* webpackChunkName: "pages/usuarios/medidas/index" */))
const _2804643c = () => interopDefault(import('..\\pages\\usuarios\\usuario\\index.vue' /* webpackChunkName: "pages/usuarios/usuario/index" */))
const _1f30cab9 = () => interopDefault(import('..\\pages\\ventas\\lista.vue' /* webpackChunkName: "pages/ventas/lista" */))
const _c14128ba = () => interopDefault(import('..\\pages\\configuracion\\articulos\\nuevo.vue' /* webpackChunkName: "pages/configuracion/articulos/nuevo" */))
const _75cbaee3 = () => interopDefault(import('..\\pages\\configuracion\\categorias\\nuevo.vue' /* webpackChunkName: "pages/configuracion/categorias/nuevo" */))
const _ec80d728 = () => interopDefault(import('..\\pages\\configuracion\\marcas\\nuevo.vue' /* webpackChunkName: "pages/configuracion/marcas/nuevo" */))
const _1682a0a2 = () => interopDefault(import('..\\pages\\configuracion\\medidas\\nuevo.vue' /* webpackChunkName: "pages/configuracion/medidas/nuevo" */))
const _666760d4 = () => interopDefault(import('..\\pages\\usuarios\\medidas\\nuevo.vue' /* webpackChunkName: "pages/usuarios/medidas/nuevo" */))
const _35ec93a1 = () => interopDefault(import('..\\pages\\usuarios\\usuario\\nuevo.vue' /* webpackChunkName: "pages/usuarios/usuario/nuevo" */))
const _532e0c81 = () => interopDefault(import('..\\pages\\configuracion\\articulos\\image\\template.vue' /* webpackChunkName: "pages/configuracion/articulos/image/template" */))
const _63bced6a = () => interopDefault(import('..\\pages\\configuracion\\articulos\\editar\\_id.vue' /* webpackChunkName: "pages/configuracion/articulos/editar/_id" */))
const _28485383 = () => interopDefault(import('..\\pages\\configuracion\\articulos\\image\\_id.vue' /* webpackChunkName: "pages/configuracion/articulos/image/_id" */))
const _c2c346ea = () => interopDefault(import('..\\pages\\configuracion\\categorias\\editar\\_id.vue' /* webpackChunkName: "pages/configuracion/categorias/editar/_id" */))
const _1aef9158 = () => interopDefault(import('..\\pages\\configuracion\\marcas\\editar\\_id.vue' /* webpackChunkName: "pages/configuracion/marcas/editar/_id" */))
const _d73a79ec = () => interopDefault(import('..\\pages\\configuracion\\medidas\\editar\\_id.vue' /* webpackChunkName: "pages/configuracion/medidas/editar/_id" */))
const _d0bb2a04 = () => interopDefault(import('..\\pages\\usuarios\\medidas\\editar\\_id.vue' /* webpackChunkName: "pages/usuarios/medidas/editar/_id" */))
const _16643ac9 = () => interopDefault(import('..\\pages\\usuarios\\usuario\\editar\\_id.vue' /* webpackChunkName: "pages/usuarios/usuario/editar/_id" */))
const _a0c9de42 = () => interopDefault(import('..\\pages\\compras\\invoice\\_id.vue' /* webpackChunkName: "pages/compras/invoice/_id" */))
const _74edb40b = () => interopDefault(import('..\\pages\\inventario\\kardex\\_id.vue' /* webpackChunkName: "pages/inventario/kardex/_id" */))
const _54300f67 = () => interopDefault(import('..\\pages\\ventas\\invoice\\_id.vue' /* webpackChunkName: "pages/ventas/invoice/_id" */))
const _47df81e2 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/cajas",
    component: _f4c4ba32,
    name: "cajas"
  }, {
    path: "/compras",
    component: _69968610,
    name: "compras"
  }, {
    path: "/inventario",
    component: _bd248004,
    name: "inventario"
  }, {
    path: "/templateadmin",
    component: _27e9bad2,
    name: "templateadmin"
  }, {
    path: "/test",
    component: _37d898e5,
    name: "test"
  }, {
    path: "/ventas",
    component: _37f75088,
    name: "ventas"
  }, {
    path: "/auth/login",
    component: _34f6803e,
    name: "auth-login"
  }, {
    path: "/cajas/historial",
    component: _2907c678,
    name: "cajas-historial"
  }, {
    path: "/compras/lista",
    component: _50d00041,
    name: "compras-lista"
  }, {
    path: "/configuracion/articulos",
    component: _dd118784,
    name: "configuracion-articulos"
  }, {
    path: "/configuracion/categorias",
    component: _67e37f7e,
    name: "configuracion-categorias"
  }, {
    path: "/configuracion/marcas",
    component: _7bd76507,
    name: "configuracion-marcas"
  }, {
    path: "/configuracion/medidas",
    component: _089a713d,
    name: "configuracion-medidas"
  }, {
    path: "/configuracion/sucursal",
    component: _59d3279e,
    name: "configuracion-sucursal"
  }, {
    path: "/usuarios/medidas",
    component: _8237bf9e,
    name: "usuarios-medidas"
  }, {
    path: "/usuarios/usuario",
    component: _2804643c,
    name: "usuarios-usuario"
  }, {
    path: "/ventas/lista",
    component: _1f30cab9,
    name: "ventas-lista"
  }, {
    path: "/configuracion/articulos/nuevo",
    component: _c14128ba,
    name: "configuracion-articulos-nuevo"
  }, {
    path: "/configuracion/categorias/nuevo",
    component: _75cbaee3,
    name: "configuracion-categorias-nuevo"
  }, {
    path: "/configuracion/marcas/nuevo",
    component: _ec80d728,
    name: "configuracion-marcas-nuevo"
  }, {
    path: "/configuracion/medidas/nuevo",
    component: _1682a0a2,
    name: "configuracion-medidas-nuevo"
  }, {
    path: "/usuarios/medidas/nuevo",
    component: _666760d4,
    name: "usuarios-medidas-nuevo"
  }, {
    path: "/usuarios/usuario/nuevo",
    component: _35ec93a1,
    name: "usuarios-usuario-nuevo"
  }, {
    path: "/configuracion/articulos/image/template",
    component: _532e0c81,
    name: "configuracion-articulos-image-template"
  }, {
    path: "/configuracion/articulos/editar/:id?",
    component: _63bced6a,
    name: "configuracion-articulos-editar-id"
  }, {
    path: "/configuracion/articulos/image/:id?",
    component: _28485383,
    name: "configuracion-articulos-image-id"
  }, {
    path: "/configuracion/categorias/editar/:id?",
    component: _c2c346ea,
    name: "configuracion-categorias-editar-id"
  }, {
    path: "/configuracion/marcas/editar/:id?",
    component: _1aef9158,
    name: "configuracion-marcas-editar-id"
  }, {
    path: "/configuracion/medidas/editar/:id?",
    component: _d73a79ec,
    name: "configuracion-medidas-editar-id"
  }, {
    path: "/usuarios/medidas/editar/:id?",
    component: _d0bb2a04,
    name: "usuarios-medidas-editar-id"
  }, {
    path: "/usuarios/usuario/editar/:id?",
    component: _16643ac9,
    name: "usuarios-usuario-editar-id"
  }, {
    path: "/compras/invoice/:id?",
    component: _a0c9de42,
    name: "compras-invoice-id"
  }, {
    path: "/inventario/kardex/:id?",
    component: _74edb40b,
    name: "inventario-kardex-id"
  }, {
    path: "/ventas/invoice/:id?",
    component: _54300f67,
    name: "ventas-invoice-id"
  }, {
    path: "/",
    component: _47df81e2,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
